/*
*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*
*                                                                             *
*                        [ Context Switch (Cortex-M3) ]                       *
*                                                                             *
*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*=====*
*/

#include <stdio.h>

typedef unsigned int    stack_t;        /* stack type (4byte) */

typedef struct {
  stack_t     *sp;
} tcb_t;

tcb_t   *current_tcb = 0;               /* �������� Task�� TCB */


extern tcb_t  task_1_tcb;
extern tcb_t  task_2_tcb;

void delay(volatile unsigned int count);



                                                 /***** [ Contex Switch ] ****/
/*------------------------ [ stack_init ] -----*/
stack_t *stack_init( void (*task_exe)(void), stack_t *sp )
{
  *sp   = (stack_t)task_exe;    /* R14 (LR) Entry address */
  *(--sp) = 0x00000012;           /* R12 */
  *(--sp) = 0x00000011;           /* R11 */
  *(--sp) = 0x00000010;           /* R10 */
  *(--sp) = 0x00000009;           /* R9 */
  *(--sp) = 0x00000008;           /* R8 */
  *(--sp) = 0x00000007;           /* R7 */
  *(--sp) = 0x00000006;           /* R6 */
  *(--sp) = 0x00000005;           /* R5 */
  *(--sp) = 0x00000004;           /* R4 */
  *(--sp) = 0x00000003;           /* R3 */
  *(--sp) = 0x00000002;           /* R2 */
  *(--sp) = 0x00000001;           /* R1 */
  *(--sp) = 0x00000000;           /* R0 */

  return sp;
}


/*------------------------ [ exchange_tcb ] ---*/
stack_t *exchange_tcb(tcb_t *rdy_tcb, stack_t *cur_sp)
{
  current_tcb->sp = cur_sp;     /* �������� Task SP ���� */
  current_tcb = rdy_tcb;        /* Task ���� */

  return (current_tcb->sp);     /* ������ Task�� SP */
}


/*------------------------ [ context_switch ] -*/
__asm void context_switch(tcb_t *rdy_tcb)
{
  IMPORT  exchange_tcb
  
  PUSH    { R0 - R12, LR }    /* Register R0 ~ R12, R14(LR) storage */
  MRS     R1, MSP             /* CPU SP(R13) get */

                              /* ���ް�  R0 : rdy_tcb,  R1 : cur_sp */
  BL      exchange_tcb
                              /* ��ȯ��  R0 : run_sp */
  
  MSR     MSP, R0             /* CPU SP(R13) set */
  POP     { R0 - R12, LR }    /* Register R0 ~ R12, R14(LR) restore */
  BX      LR                  /* Return (Task exe) */
}


/*------------------------------- [ start ] ---*/
__asm void start(stack_t *run_sp)
{
  /* R0 : run_sp */
  
  MSR     MSP, R0             /* CPU SP(R13) set */
  POP     { R0 - R12, LR }    /* Register R0 ~ R12, R14(LR) restore */
  BX      LR                  /* Return (Task exe) */
}


                                                 /************* [ Tasks ] ****/
/*------------------------------ [ task_1 ] ---*/
tcb_t   task_1_tcb;
stack_t task1_stack[100];

void task_1_exe(void)
{
  int count = 1000;
  
  printf("[2] Task 1 Start \r\n");

  context_switch(&task_2_tcb);

  for(;;)
  {
    delay(1000000);
    printf("Task 1   (%d) \r\n", count++);
    context_switch(&task_2_tcb);
  }
}


/*------------------------------ [ task_2 ] ---*/
tcb_t   task_2_tcb;
stack_t task2_stack[100];

void task_2_exe(void)
{
  int count = 2000;
  
  printf("[3] Task 2 Start \r\n");
  
  context_switch(&task_1_tcb);

  for(;;)
  {
    delay(2000000);
    printf("Task 2   (%d) \r\n\r\n", count++);
    context_switch(&task_1_tcb);
  }
}


/*=============================================== main() ====================*/
int main(void)
{
  printf("[1] Main Start \r\n");

  task_1_tcb.sp = stack_init( task_1_exe, &task1_stack[100-1] );
  task_2_tcb.sp = stack_init( task_2_exe, &task2_stack[100-1] );

  current_tcb = &task_1_tcb;
  start(current_tcb->sp);
  
  return 0;
}


/*------------------------------- [ delay ] ---*/
void delay(volatile unsigned int count)
{
  while(count)
  {
    count--;
  }
}



/*----------------------------------- [ Cortex-M3 Debug (printf) Viewer ] ****/
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000


struct __FILE { int handle; /* Add whatever needed */ };
FILE __stdout;
FILE __stdin;

/*------------------------------- [ fputc ] ---*/
int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}
